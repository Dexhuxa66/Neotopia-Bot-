import stay_world as bot
import struct


class FakeSocket:
    closed = False

    def __init__(self):
        self.messages = []

    def send(self, message):
        self.messages.append(message)


class FakeMover:
    def __init__(self, x=0, y=0):
        self.ws = FakeSocket()
        self.x = x
        self.y = y
        self.alive = True
        self.facing_left = False


def configure_world(monkeypatch):
    monkeypatch.setattr(bot, "WORLD_W", 10)
    monkeypatch.setattr(bot, "WORLD_H", 10)
    monkeypatch.setattr(bot, "NAME_TO_ID", {"AIR": 0, "DIRT": 3, "STONE": 5})
    monkeypatch.setattr(bot, "NAME_BY_ID", {0: "AIR", 3: "DIRT", 5: "STONE"})
    monkeypatch.setattr(bot, "BLOCKS", {})
    monkeypatch.setattr(bot, "INVENTORY", {})
    monkeypatch.setattr(bot, "GEMS", 0)
    monkeypatch.setattr(bot, "INVENTORY_VERSION", 0)
    monkeypatch.setattr(bot, "MAX_SLOTS", 10)
    monkeypatch.setattr(bot, "DROPPED_ITEMS", {})
    monkeypatch.setattr(bot, "PICKUP_OPS", {})
    monkeypatch.setattr(bot, "AUTO_COLLECT_NEARBY", False)


def test_place_sends_block_update(monkeypatch):
    configure_world(monkeypatch)
    mover = FakeMover(x=0, y=0)

    assert bot.do_place(mover, 1, 0, "DIRT") is True
    assert len(mover.ws.messages) == 1
    message = bot.json.loads(mover.ws.messages[0])
    assert message["type"] == "block_update"
    assert message["action"] == "place"
    assert message["blockType"] == "DIRT"
    assert (message["x"], message["y"]) == (1, 0)


def test_place_rejects_invalid_or_out_of_range_tile(monkeypatch):
    configure_world(monkeypatch)
    mover = FakeMover(x=0, y=0)

    assert bot.do_place(mover, -1, 0, "DIRT") is False
    assert bot.do_place(mover, 9, 9, "DIRT") is False
    assert mover.ws.messages == []


def test_place_rejects_occupied_tile(monkeypatch):
    configure_world(monkeypatch)
    bot.BLOCKS[1] = 5
    mover = FakeMover(x=0, y=0)

    assert bot.do_place(mover, 1, 0, "DIRT") is False
    assert mover.ws.messages == []


def test_msg_uses_client_chat_text_field():
    mover = FakeMover()

    assert bot.do_chat(mover, "halo") is True
    message = bot.json.loads(mover.ws.messages[0])
    assert message == {"type": "chat", "text": "halo"}


def test_msg_rejects_empty_or_disconnected():
    mover = FakeMover()
    assert bot.do_chat(mover, "   ") is False
    mover.alive = False
    assert bot.do_chat(mover, "halo") is False


def test_drop_sends_client_packet_from_inventory(monkeypatch):
    configure_world(monkeypatch)
    bot.INVENTORY["PHONE"] = 2
    mover = FakeMover(x=100, y=200)

    assert bot.do_drop(mover, "PHONE", 1) is True
    message = bot.json.loads(mover.ws.messages[0])
    assert message["type"] == "dropped_item"
    assert message["itemType"] == "PHONE"
    assert message["count"] == 1
    assert message["pos"] == {"x": 120, "y": 200}
    assert len(message["opId"]) > 10


def test_drop_rejects_missing_count_and_non_droppable_items(monkeypatch):
    configure_world(monkeypatch)
    bot.INVENTORY.update({"PHONE": 1, "FIST": 1})
    mover = FakeMover()

    assert bot.do_drop(mover, "PHONE", 2) is False
    assert bot.do_drop(mover, "FIST", 1) is False
    assert mover.ws.messages == []


def test_inventory_snapshot_and_drop_ack_update_state(monkeypatch):
    configure_world(monkeypatch)
    mover = FakeMover()

    bot.handle_message(bot.json.dumps({
        "type": "inventory_snapshot",
        "inventory": [{"type": "PHONE", "count": 2}],
        "gems": 4,
        "inventoryVersion": 7,
        "maxSlots": 10,
    }), mover)
    assert bot.INVENTORY == {"PHONE": 2}
    assert bot.GEMS == 4
    assert bot.INVENTORY_VERSION == 7

    bot.handle_message(bot.json.dumps({
        "type": "drop_ack",
        "opId": "op-1",
        "itemType": "PHONE",
        "count": 1,
        "inventory": [{"type": "PHONE", "count": 1}],
        "inventoryVersion": 8,
        "groundPresent": True,
        "id": "drop-1",
        "pos": {"x": 20, "y": 30},
    }), mover)
    assert bot.INVENTORY == {"PHONE": 1}
    assert bot.INVENTORY_VERSION == 8
    assert bot.DROPPED_ITEMS["drop-1"]["count"] == 1


def test_pickup_sends_packet_for_nearby_ground_item(monkeypatch):
    configure_world(monkeypatch)
    bot.INVENTORY["PHONE"] = 1
    bot.DROPPED_ITEMS["drop-1"] = {
        "id": "drop-1", "itemType": "DIRT", "count": 2,
        "pos": {"x": 20, "y": 20},
    }
    mover = FakeMover(x=0, y=0)

    assert bot.do_pickup(mover, "drop-1") is True
    message = bot.json.loads(mover.ws.messages[0])
    assert message["type"] == "pickup_item"
    assert message["id"] == "drop-1"
    assert message["opId"] in bot.PICKUP_OPS


def test_pickup_rejects_item_out_of_range(monkeypatch):
    configure_world(monkeypatch)
    bot.DROPPED_ITEMS["drop-1"] = {
        "id": "drop-1", "itemType": "DIRT", "count": 1,
        "pos": {"x": 100, "y": 100},
    }
    mover = FakeMover(x=0, y=0)

    assert bot.do_pickup(mover, "drop-1") is False
    assert mover.ws.messages == []


def test_decode_binary_drop_snapshot(monkeypatch):
    configure_world(monkeypatch)
    payload = bytearray([17, 1])
    payload.extend((123).to_bytes(4, "big"))       # snapshot ID
    payload.extend((0).to_bytes(2, "big"))         # chunk index
    payload.extend((1).to_bytes(2, "big"))         # chunk count
    payload.extend((1).to_bytes(2, "big"))         # entries in chunk
    payload.extend((1).to_bytes(4, "big"))         # total count
    payload.extend(bytes([1]))                      # textual ID
    payload.extend((5).to_bytes(2, "big"))         # item registry ID -> STONE
    payload.extend(bytes([2]))                      # count
    payload.extend(struct.pack(">ff", 20.0, 20.0))
    payload.extend(bytes([5]))
    payload.extend(b"drop1")

    chunk = bot.decode_drop_snapshot(bytes(payload))
    assert chunk is not None
    assert chunk["drops"][0]["id"] == "drop1"
    assert chunk["drops"][0]["itemType"] == "STONE"
    drops = bot.apply_drop_snapshot_chunk(chunk)
    assert len(drops) == 1
    assert bot.DROPPED_ITEMS["drop1"]["count"] == 2


def test_find_path_prefers_one_tile_walk_steps(monkeypatch):
    configure_world(monkeypatch)
    for tx in range(bot.WORLD_W):
        bot.BLOCKS[9 * bot.WORLD_W + tx] = 3

    path = bot.find_path((8, 8), (3, 8))

    assert path is not None
    assert [kind for _, kind, _ in path] == ["walk"] * 5
    assert [dest for _, _, dest in path] == [
        (7, 8), (6, 8), (5, 8), (4, 8), (3, 8)
    ]


def test_find_path_keeps_jump_fallback_for_gap(monkeypatch):
    configure_world(monkeypatch)
    for tx in (0, 1, 2, 7, 8, 9):
        bot.BLOCKS[9 * bot.WORLD_W + tx] = 3

    path = bot.find_path((1, 8), (8, 8))

    assert path is not None
    assert path[-1][2] == (8, 8)
    assert any(kind == "jump" for _, kind, _ in path)


def test_air_goto_moves_to_tile_center_without_support(monkeypatch):
    configure_world(monkeypatch)
    monkeypatch.setattr(bot.time, "sleep", lambda _: None)
    mover = bot.Mover(FakeSocket(), 0, 0)

    assert bot.do_air_goto(mover, 1, 1) is True
    assert (mover.x, mover.y) == (37.0, 35.0)
    assert mover.busy is False
    assert mover.target_x is None
    assert mover.target_y is None
    assert len(mover.ws.messages) > 0


def test_air_goto_aborts_after_server_correction(monkeypatch):
    configure_world(monkeypatch)
    monkeypatch.setattr(bot.time, "sleep", lambda _: None)
    mover = bot.Mover(FakeSocket(), 0, 0)

    original_send = mover.ws.send

    def correct_on_first_send(message):
        original_send(message)
        if len(mover.ws.messages) == 1:
            mover.correct(0, 0)

    mover.ws.send = correct_on_first_send

    assert bot.do_air_goto(mover, 1, 1) is False
    assert (mover.x, mover.y) == (0, 0)
    assert mover.busy is False
