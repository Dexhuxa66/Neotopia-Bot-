#!/usr/bin/env python3
"""
Neotopia Account & TempMail All-in-One Tool
- Dynamic DB_FILE path (automatically in the same directory as script)
- Generates tempmail accounts with random email & natural display names
- Silent magic link authentication -> extracts refreshToken & apiKey -> saves to accounts.json
"""

import sys
import os
import json
import random
import string
import time
import urllib.request
import requests
import re

MAIL_TM_API = "https://api.mail.tm"
# Automatically set accounts.json in the same folder as this script
DB_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "accounts.json")
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

DEFAULT_PASSWORD = "TempPassword123!"
FIREBASE_KEY = "AIzaSyBkFnfnk2i4moaF5KnzVAuEZE_6kSjqQds"

NAME_PREFIXES = ["riki", "soyu", "dori", "bintang", "ryan", "raka", "wisp", "reza", "kevin", "nova", "luna", "kai", "zara", "bayu", "dimas"]

def load_accounts():
    if os.path.exists(DB_FILE):
        try:
            with open(DB_FILE, "r") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}

def save_account(address, password, token=None, display_name=None, refresh_token=None):
    accounts = load_accounts()
    entry = accounts.get(address, {
        "password": password,
        "token": token,
        "display_name": display_name,
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S")
    })
    if token:
        entry["token"] = token
    if display_name:
        entry["display_name"] = display_name
    if refresh_token:
        entry["refresh_token"] = refresh_token
        entry["apiKey"] = FIREBASE_KEY
        entry["api_key"] = FIREBASE_KEY
    accounts[address] = entry
    with open(DB_FILE, "w") as f:
        json.dump(accounts, f, indent=2)

def save_bot_account(email, auth_data, display_name=None):
    """Write the auth result in the format expected by stay_world.py."""
    safe_email = re.sub(r"[^a-zA-Z0-9_.-]+", "_", email)
    path = os.path.join(BASE_DIR, f"guest_account_{safe_email}.json")
    account = {
        "api_key": FIREBASE_KEY,
        "id_token": auth_data["idToken"],
        "refresh_token": auth_data["refreshToken"],
        "uid": auth_data["localId"],
        "canonical_name": display_name or "",
        "type": "firebase_email_link",
        "platform": "desktop",
        "world": "778839",
    }
    with open(path, "w") as f:
        json.dump(account, f, indent=2)
    os.chmod(path, 0o600)
    return path

def generate_random_email():
    letters_digits = string.ascii_lowercase + string.digits
    user_part = "".join(random.choices(letters_digits, k=12))
    return f"{user_part}@maxxspace.com"

def generate_random_name():
    prefix = random.choice(NAME_PREFIXES)
    number = random.randint(100, 9999)
    return f"{prefix}{number}"

def create_mailtm_account(email, password):
    try:
        res = requests.post(f"{MAIL_TM_API}/accounts", json={
            "address": email,
            "password": password
        }, timeout=10)
        if res.status_code in [200, 201]:
            tok_res = requests.post(f"{MAIL_TM_API}/token", json={
                "address": email,
                "password": password
            }, timeout=10)
            if tok_res.status_code == 200:
                return tok_res.json().get("token")
    except Exception as e:
        print(f"Mail.tm error for {email}: {e}")
    return None

def cmd_generate():
    try:
        jumlah_str = input("Masukkan JUMLAH akun yang ingin dibuat: ")
        jumlah = int(jumlah_str)
    except Exception:
        print("Input harus berupa angka.")
        return

    print(f"\nMembuat {jumlah} akun baru secara otomatis...")
    
    for i in range(1, jumlah + 1):
        email = generate_random_email()
        display_name = generate_random_name()
        password = DEFAULT_PASSWORD
        
        print(f"\n[{i}/{jumlah}] Email: {email} | Nama: {display_name}")
        
        token = create_mailtm_account(email, password)
        if not token:
            print(f"  -> Gagal membuat akun mail.tm")
            continue
        print(f"  -> Akun mail.tm berhasil dibuat.")
        
        save_account(email, password, token, display_name)
        print(f"  -> Tersimpan di {DB_FILE}")

    print(f"\nSelesai! {jumlah} akun berhasil dibuat.")

def cmd_get_credentials(email):
    accounts = load_accounts()
    if email not in accounts:
        print(f"Email {email} tidak ditemukan di {DB_FILE}")
        return
    
    # 1. Send OOB code
    url_send = f"https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key={FIREBASE_KEY}"
    payload = {"requestType": "EMAIL_SIGNIN", "email": email, "continueUrl": "https://playneotopia.com/", "canHandleCodeInApp": True}
    req = urllib.request.Request(url_send, data=json.dumps(payload).encode(), headers={"Content-Type": "application/json"})
    try:
        urllib.request.urlopen(req, timeout=10)
    except Exception as e:
        print(f"Error request magic link: {e}")
        return

    time.sleep(5)

    # 2. Check inbox
    token = accounts[email]["token"]
    headers = {"Authorization": f"Bearer {token}"}
    res = requests.get(f"{MAIL_TM_API}/messages", headers=headers, timeout=10)
    msgs = res.json().get("hydra:member", [])
    if not msgs:
        print("Belum ada pesan masuk di inbox.")
        return

    latest_msg = msgs[0]
    msg_id = latest_msg["id"]
    msg_res = requests.get(f"{MAIL_TM_API}/messages/{msg_id}", headers=headers, timeout=10)
    html_content = msg_res.json().get("html", [""])[0]

    match = re.search(r"oobCode=([a-zA-Z0-9_-]+)", html_content)
    if not match:
        print("Gagal mengekstrak oobCode dari email.")
        return

    oobCode = match.group(1)

    # 3. Exchange oobCode for tokens
    url_signin = f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithEmailLink?key={FIREBASE_KEY}"
    signin_payload = {"email": email, "oobCode": oobCode, "returnSecureToken": True}
    req2 = urllib.request.Request(url_signin, data=json.dumps(signin_payload).encode(), headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req2, timeout=10) as resp2:
            res_data = json.loads(resp2.read().decode())
            idToken = res_data["idToken"]
            refresh_token = res_data["refreshToken"]
            
            # Update display name if saved
            display_name = accounts[email].get("display_name")
            if display_name:
                url_update = f"https://identitytoolkit.googleapis.com/v1/accounts:update?key={FIREBASE_KEY}"
                update_payload = {"idToken": idToken, "displayName": display_name, "returnSecureToken": True}
                req_up = urllib.request.Request(url_update, data=json.dumps(update_payload).encode(), headers={"Content-Type": "application/json"})
                urllib.request.urlopen(req_up, timeout=10)

            # Save auth data to accounts.json and export a bot-ready account file.
            save_account(email, accounts[email]["password"], refresh_token=refresh_token)
            bot_account = save_bot_account(
                email, res_data, display_name=display_name
            )

            print(f"\n[INFO] Auth berhasil. Data akun tersimpan di {DB_FILE}.")
            print(f"[INFO] File bot siap pakai: {bot_account}")
            print("[INFO] Refresh token tidak ditampilkan di terminal.")
    except Exception as e:
        print(f"Gagal login: {e}")

def main():
    if len(sys.argv) > 1 and sys.argv[1] == "auth":
        if len(sys.argv) > 2:
            cmd_get_credentials(sys.argv[2])
        else:
            accounts = load_accounts()
            emails = list(accounts.keys())
            if emails:
                cmd_get_credentials(emails[0])
            else:
                print(f"Tidak ada akun di {DB_FILE}")
    else:
        cmd_generate()

if __name__ == "__main__":
    main()
